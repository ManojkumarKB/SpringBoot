package com.manoj.web;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@ Controller
public class AddController {
	
	@RequestMapping("/add")
	public ModelAndView add(@RequestParam("txt1") int t1,@RequestParam("txt2") int t2)
	{
		ModelAndView mv=new ModelAndView();
		int k=t1+t2;
		mv.addObject("result",k);
		mv.setViewName("result.jsp");
		
		return mv;
	}

}
